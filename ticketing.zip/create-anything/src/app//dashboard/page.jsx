"use client";
import React from "react";

function MainComponent() {
  const { data: user, loading: userLoading } = useUser();
  const [activeTab, setActiveTab] = useState("overview");
  const [events, setEvents] = useState([]);
  const [categories, setCategories] = useState([]);
  const [userStats, setUserStats] = useState({
    totalEvents: 0,
    totalTicketsSold: 0,
    totalRevenue: 0,
    pendingEvents: 0,
  });
  const [loadingEvents, setLoadingEvents] = useState(true);
  const [loadingStats, setLoadingStats] = useState(true);
  const [error, setError] = useState(null);
  const [showCreateEvent, setShowCreateEvent] = useState(false);
  const [showProfileEdit, setShowProfileEdit] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState(null);

  const [newEvent, setNewEvent] = useState({
    title: "",
    description: "",
    category: "",
    date: "",
    time: "",
    location: "",
    venue: "",
    ticketPrice: "",
    totalTickets: "",
    image: null,
  });

  const [profileData, setProfileData] = useState({
    name: "",
    email: "",
    phone: "",
    bio: "",
  });

  useEffect(() => {
    if (user && !userLoading) {
      fetchUserEvents();
      fetchUserStats();
      fetchCategories();
      fetchVerificationStatus();
      setProfileData({
        name: user.name || "",
        email: user.email || "",
        phone: user.phone || "",
        bio: user.bio || "",
      });
    }
  }, [user, userLoading]);

  const fetchUserEvents = async () => {
    try {
      setLoadingEvents(true);
      const response = await fetch("/api/events/list", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userOnly: true }),
      });

      if (!response.ok) throw new Error("Failed to fetch events");
      const data = await response.json();
      setEvents(data.events || []);
    } catch (error) {
      console.error("Error fetching events:", error);
      setError("Failed to load your events");
    } finally {
      setLoadingEvents(false);
    }
  };

  const fetchUserStats = async () => {
    try {
      setLoadingStats(true);
      const response = await fetch("/api/admin/analytics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userOnly: true }),
      });

      if (!response.ok) throw new Error("Failed to fetch stats");
      const data = await response.json();
      setUserStats({
        totalEvents: data.totalEvents || 0,
        totalTicketsSold: data.totalTicketsSold || 0,
        totalRevenue: data.totalRevenue || 0,
        pendingEvents: data.pendingEvents || 0,
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
    } finally {
      setLoadingStats(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await fetch("/api/categories/list", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      if (!response.ok) throw new Error("Failed to fetch categories");
      const data = await response.json();
      setCategories(data.categories || []);
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  const fetchVerificationStatus = async () => {
    try {
      const response = await fetch("/api/user/verification-status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      if (response.ok) {
        const data = await response.json();
        setVerificationStatus(data.status);
      }
    } catch (error) {
      console.error("Error fetching verification status:", error);
    }
  };

  const handleCreateEvent = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/events/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...newEvent,
          datetime: `${newEvent.date}T${newEvent.time}`,
          ticket_price: parseFloat(newEvent.ticketPrice),
          total_tickets: parseInt(newEvent.totalTickets),
        }),
      });

      if (!response.ok) throw new Error("Failed to create event");

      setNewEvent({
        title: "",
        description: "",
        category: "",
        date: "",
        time: "",
        location: "",
        venue: "",
        ticketPrice: "",
        totalTickets: "",
        image: null,
      });
      setShowCreateEvent(false);
      fetchUserEvents();
      fetchUserStats();
    } catch (error) {
      console.error("Error creating event:", error);
      setError("Failed to create event");
    }
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/user/update-profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profileData),
      });

      if (!response.ok) throw new Error("Failed to update profile");
      setShowProfileEdit(false);
    } catch (error) {
      console.error("Error updating profile:", error);
      setError("Failed to update profile");
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "approved":
        return "bg-green-500/20 text-green-400";
      case "pending":
        return "bg-yellow-500/20 text-yellow-400";
      case "rejected":
        return "bg-red-500/20 text-red-400";
      default:
        return "bg-gray-500/20 text-gray-400";
    }
  };

  const getVerificationBadge = () => {
    if (!verificationStatus) return null;

    const badges = {
      verified: {
        icon: "fa-check-circle",
        color: "text-green-400",
        text: "Verified",
      },
      pending: { icon: "fa-clock", color: "text-yellow-400", text: "Pending" },
      rejected: {
        icon: "fa-times-circle",
        color: "text-red-400",
        text: "Rejected",
      },
    };

    const badge = badges[verificationStatus];
    if (!badge) return null;

    return (
      <span
        className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${badge.color} bg-white/10`}
      >
        <i className={`fas ${badge.icon} mr-1`}></i>
        {badge.text}
      </span>
    );
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460] flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460] flex items-center justify-center">
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 text-center">
          <i className="fas fa-sign-in-alt text-blue-400 text-6xl mb-4"></i>
          <h2 className="text-2xl font-bold text-white mb-4">Please Sign In</h2>
          <p className="text-white/80 mb-6">
            You need to be signed in to access your dashboard.
          </p>
          <a
            href="/account/signin?callbackUrl=/dashboard"
            className="bg-[#357AFF] text-white px-6 py-3 rounded-lg hover:bg-[#2E69DE] transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460]">
      {/* Header */}
      <header className="bg-white/10 backdrop-blur-md border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-white">
                EventTix Dashboard
              </h1>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a
                href="/"
                className="text-white/80 hover:text-[#357AFF] transition-colors"
              >
                Home
              </a>
              <a
                href="/events"
                className="text-white/80 hover:text-[#357AFF] transition-colors"
              >
                Browse Events
              </a>
              <a
                href="/my-tickets"
                className="text-white/80 hover:text-[#357AFF] transition-colors"
              >
                My Tickets
              </a>
            </nav>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-white/90">
                  {user.name || user.email}
                </span>
                {getVerificationBadge()}
              </div>
              <a
                href="/account/logout"
                className="text-sm text-white/80 hover:text-[#357AFF] transition-colors"
              >
                Logout
              </a>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">
            Welcome back, {user.name || "User"}!
          </h2>
          <p className="text-white/70">
            Manage your events, track performance, and grow your audience.
          </p>
        </div>

        {error && (
          <div className="bg-red-500/20 border border-red-500/50 text-red-200 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        {/* Tab Navigation */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 bg-white/10 backdrop-blur-md rounded-lg p-2">
            {[
              { id: "overview", label: "Overview", icon: "fa-chart-line" },
              { id: "events", label: "My Events", icon: "fa-calendar-alt" },
              { id: "create", label: "Create Event", icon: "fa-plus" },
              { id: "analytics", label: "Analytics", icon: "fa-chart-bar" },
              { id: "profile", label: "Profile", icon: "fa-user" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 ${
                  activeTab === tab.id
                    ? "bg-[#357AFF] text-white"
                    : "text-white/70 hover:text-white hover:bg-white/10"
                }`}
              >
                <i className={`fas ${tab.icon}`}></i>
                <span className="hidden sm:inline">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Total Events</p>
                    <p className="text-2xl font-bold text-white">
                      {userStats.totalEvents}
                    </p>
                  </div>
                  <div className="bg-blue-500/20 p-3 rounded-lg">
                    <i className="fas fa-calendar-alt text-blue-400 text-xl"></i>
                  </div>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Tickets Sold</p>
                    <p className="text-2xl font-bold text-white">
                      {userStats.totalTicketsSold}
                    </p>
                  </div>
                  <div className="bg-green-500/20 p-3 rounded-lg">
                    <i className="fas fa-ticket-alt text-green-400 text-xl"></i>
                  </div>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Total Revenue</p>
                    <p className="text-2xl font-bold text-white">
                      ₵{userStats.totalRevenue.toLocaleString()}
                    </p>
                  </div>
                  <div className="bg-purple-500/20 p-3 rounded-lg">
                    <i className="fas fa-dollar-sign text-purple-400 text-xl"></i>
                  </div>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Pending Events</p>
                    <p className="text-2xl font-bold text-white">
                      {userStats.pendingEvents}
                    </p>
                  </div>
                  <div className="bg-yellow-500/20 p-3 rounded-lg">
                    <i className="fas fa-clock text-yellow-400 text-xl"></i>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Events */}
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
              <h3 className="text-xl font-semibold text-white mb-4">
                Recent Events
              </h3>
              {loadingEvents ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div
                      key={i}
                      className="bg-white/5 rounded-lg p-4 animate-pulse"
                    >
                      <div className="h-4 bg-white/10 rounded mb-2"></div>
                      <div className="h-3 bg-white/10 rounded w-3/4"></div>
                    </div>
                  ))}
                </div>
              ) : events.length === 0 ? (
                <div className="text-center py-8">
                  <i className="fas fa-calendar-plus text-white/40 text-4xl mb-4"></i>
                  <p className="text-white/70">No events created yet</p>
                  <button
                    onClick={() => setActiveTab("create")}
                    className="mt-4 bg-[#357AFF] text-white px-6 py-2 rounded-lg hover:bg-[#2E69DE] transition-colors"
                  >
                    Create Your First Event
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {events.slice(0, 5).map((event) => (
                    <div
                      key={event.id}
                      className="flex items-center justify-between p-4 bg-white/5 rounded-lg"
                    >
                      <div>
                        <h4 className="text-white font-medium">
                          {event.title}
                        </h4>
                        <p className="text-white/70 text-sm">
                          {new Date(event.datetime).toLocaleDateString()} •{" "}
                          {event.location}
                        </p>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span
                          className={`px-2 py-1 rounded text-xs ${getStatusColor(
                            event.status
                          )}`}
                        >
                          {event.status}
                        </span>
                        <span className="text-white/70 text-sm">
                          {event.tickets_sold || 0}/{event.total_tickets} sold
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Events Tab */}
        {activeTab === "events" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-2xl font-bold text-white">My Events</h3>
              <button
                onClick={() => setActiveTab("create")}
                className="bg-[#357AFF] text-white px-6 py-3 rounded-lg hover:bg-[#2E69DE] transition-colors flex items-center space-x-2"
              >
                <i className="fas fa-plus"></i>
                <span>Create Event</span>
              </button>
            </div>

            {loadingEvents ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div
                    key={i}
                    className="bg-white/10 rounded-xl p-6 animate-pulse"
                  >
                    <div className="h-32 bg-white/10 rounded-lg mb-4"></div>
                    <div className="h-4 bg-white/10 rounded mb-2"></div>
                    <div className="h-3 bg-white/10 rounded w-3/4"></div>
                  </div>
                ))}
              </div>
            ) : events.length === 0 ? (
              <div className="text-center py-12">
                <i className="fas fa-calendar-plus text-white/40 text-6xl mb-4"></i>
                <h4 className="text-xl font-semibold text-white mb-2">
                  No Events Yet
                </h4>
                <p className="text-white/70 mb-6">
                  Start creating amazing events for your audience
                </p>
                <button
                  onClick={() => setActiveTab("create")}
                  className="bg-[#357AFF] text-white px-8 py-3 rounded-lg hover:bg-[#2E69DE] transition-colors"
                >
                  Create Your First Event
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {events.map((event) => (
                  <div
                    key={event.id}
                    className="bg-white/10 backdrop-blur-md rounded-xl overflow-hidden border border-white/20"
                  >
                    <div className="h-32 bg-gradient-to-r from-[#357AFF] to-[#00D4FF] flex items-center justify-center">
                      <i className="fas fa-calendar-alt text-white text-3xl"></i>
                    </div>
                    <div className="p-6">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="text-lg font-semibold text-white">
                          {event.title}
                        </h4>
                        <span
                          className={`px-2 py-1 rounded text-xs ${getStatusColor(
                            event.status
                          )}`}
                        >
                          {event.status}
                        </span>
                      </div>
                      <p className="text-white/70 text-sm mb-3 line-clamp-2">
                        {event.description}
                      </p>
                      <div className="space-y-2 text-sm text-white/70">
                        <div className="flex items-center">
                          <i className="fas fa-calendar mr-2"></i>
                          {new Date(event.datetime).toLocaleDateString()}
                        </div>
                        <div className="flex items-center">
                          <i className="fas fa-map-marker-alt mr-2"></i>
                          {event.location}
                        </div>
                        <div className="flex items-center">
                          <i className="fas fa-ticket-alt mr-2"></i>
                          {event.tickets_sold || 0}/{event.total_tickets} sold
                        </div>
                      </div>
                      <div className="mt-4 pt-4 border-t border-white/20">
                        <div className="flex justify-between items-center">
                          <span className="text-white font-semibold">
                            ₵{event.ticket_price}
                          </span>
                          <button className="text-[#357AFF] hover:text-[#2E69DE] transition-colors">
                            <i className="fas fa-edit mr-1"></i>
                            Edit
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Create Event Tab */}
        {activeTab === "create" && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20">
              <h3 className="text-2xl font-bold text-white mb-6">
                Create New Event
              </h3>

              <form onSubmit={handleCreateEvent} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white/70 text-sm mb-2">
                      Event Title
                    </label>
                    <input
                      type="text"
                      value={newEvent.title}
                      onChange={(e) =>
                        setNewEvent({ ...newEvent, title: e.target.value })
                      }
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50"
                      placeholder="Enter event title"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">
                      Category
                    </label>
                    <select
                      value={newEvent.category}
                      onChange={(e) =>
                        setNewEvent({ ...newEvent, category: e.target.value })
                      }
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white"
                      required
                    >
                      <option value="">Select category</option>
                      {categories.map((category) => (
                        <option key={category.id} value={category.name}>
                          {category.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">
                    Description
                  </label>
                  <textarea
                    value={newEvent.description}
                    onChange={(e) =>
                      setNewEvent({ ...newEvent, description: e.target.value })
                    }
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50"
                    placeholder="Describe your event"
                    rows="4"
                    required
                  ></textarea>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white/70 text-sm mb-2">
                      Date
                    </label>
                    <input
                      type="date"
                      value={newEvent.date}
                      onChange={(e) =>
                        setNewEvent({ ...newEvent, date: e.target.value })
                      }
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">
                      Time
                    </label>
                    <input
                      type="time"
                      value={newEvent.time}
                      onChange={(e) =>
                        setNewEvent({ ...newEvent, time: e.target.value })
                      }
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white/70 text-sm mb-2">
                      Location
                    </label>
                    <input
                      type="text"
                      value={newEvent.location}
                      onChange={(e) =>
                        setNewEvent({ ...newEvent, location: e.target.value })
                      }
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50"
                      placeholder="City, Country"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">
                      Venue
                    </label>
                    <input
                      type="text"
                      value={newEvent.venue}
                      onChange={(e) =>
                        setNewEvent({ ...newEvent, venue: e.target.value })
                      }
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50"
                      placeholder="Venue name"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white/70 text-sm mb-2">
                      Ticket Price (₵)
                    </label>
                    <input
                      type="number"
                      value={newEvent.ticketPrice}
                      onChange={(e) =>
                        setNewEvent({
                          ...newEvent,
                          ticketPrice: e.target.value,
                        })
                      }
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50"
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">
                      Total Tickets
                    </label>
                    <input
                      type="number"
                      value={newEvent.totalTickets}
                      onChange={(e) =>
                        setNewEvent({
                          ...newEvent,
                          totalTickets: e.target.value,
                        })
                      }
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50"
                      placeholder="100"
                      min="1"
                      required
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-4">
                  <button
                    type="button"
                    onClick={() => setActiveTab("events")}
                    className="px-6 py-3 text-white/70 hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-[#357AFF] text-white px-8 py-3 rounded-lg hover:bg-[#2E69DE] transition-colors"
                  >
                    Create Event
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === "analytics" && (
          <div className="space-y-8">
            <h3 className="text-2xl font-bold text-white">Event Analytics</h3>

            {/* Performance Overview */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
                <h4 className="text-xl font-semibold text-white mb-4">
                  Revenue Trend
                </h4>
                <div className="h-64 flex items-end justify-between space-x-2">
                  {Array.from({ length: 7 }).map((_, index) => (
                    <div key={index} className="flex flex-col items-center">
                      <div
                        className="bg-gradient-to-t from-[#357AFF] to-[#00D4FF] rounded-t"
                        style={{
                          height: `${Math.random() * 200 + 20}px`,
                          width: "30px",
                        }}
                      ></div>
                      <span className="text-white/70 text-xs mt-2">
                        {new Date(
                          Date.now() - (6 - index) * 24 * 60 * 60 * 1000
                        ).toLocaleDateString("en-US", {
                          weekday: "short",
                        })}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
                <h4 className="text-xl font-semibold text-white mb-4">
                  Top Performing Events
                </h4>
                <div className="space-y-4">
                  {events.slice(0, 5).map((event, index) => (
                    <div
                      key={event.id}
                      className="flex items-center justify-between"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-[#357AFF] rounded-full flex items-center justify-center text-white text-sm font-bold">
                          {index + 1}
                        </div>
                        <div>
                          <p className="text-white font-medium">
                            {event.title}
                          </p>
                          <p className="text-white/70 text-sm">
                            {event.category}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-white font-semibold">
                          ₵
                          {(
                            (event.tickets_sold || 0) * event.ticket_price
                          ).toLocaleString()}
                        </p>
                        <p className="text-white/70 text-sm">
                          {event.tickets_sold || 0} sold
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Profile Tab */}
        {activeTab === "profile" && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border border-white/20">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-white">
                  Profile Settings
                </h3>
                <div className="flex items-center space-x-2">
                  {getVerificationBadge()}
                  {verificationStatus !== "verified" && (
                    <button className="text-[#357AFF] hover:text-[#2E69DE] transition-colors text-sm">
                      Request Verification
                    </button>
                  )}
                </div>
              </div>

              <form onSubmit={handleUpdateProfile} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white/70 text-sm mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      value={profileData.name}
                      onChange={(e) =>
                        setProfileData({ ...profileData, name: e.target.value })
                      }
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50"
                      placeholder="Your full name"
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      value={profileData.email}
                      onChange={(e) =>
                        setProfileData({
                          ...profileData,
                          email: e.target.value,
                        })
                      }
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={profileData.phone}
                    onChange={(e) =>
                      setProfileData({ ...profileData, phone: e.target.value })
                    }
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50"
                    placeholder="+233 XX XXX XXXX"
                  />
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">
                    Bio
                  </label>
                  <textarea
                    value={profileData.bio}
                    onChange={(e) =>
                      setProfileData({ ...profileData, bio: e.target.value })
                    }
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50"
                    placeholder="Tell us about yourself..."
                    rows="4"
                  ></textarea>
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="bg-[#357AFF] text-white px-8 py-3 rounded-lg hover:bg-[#2E69DE] transition-colors"
                  >
                    Update Profile
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;