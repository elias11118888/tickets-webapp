async function handler({ phone, code, message, type = "verification" }) {
  const session = getSession();

  if (!session || !session.user?.id) {
    return { success: false, error: "Authentication required" };
  }

  if (!phone) {
    return { success: false, error: "Phone number is required" };
  }

  if (!code && !message) {
    return { success: false, error: "Either code or message is required" };
  }

  const phoneRegex = /^\+?[\d\s\-\(\)]{10,15}$/;
  if (!phoneRegex.test(phone)) {
    return { success: false, error: "Invalid phone number format" };
  }

  try {
    const userId = session.user.id;
    const smsMessage =
      message ||
      `Your EventTix verification code is: ${code}. This code will expire in 10 minutes.`;

    if (type === "verification" && code) {
      const existingVerification = await sql`
        SELECT id FROM sms_verifications 
        WHERE user_id = ${userId} 
        AND phone = ${phone} 
        AND verified = false 
        AND expires_at > NOW()
      `;

      if (existingVerification.length > 0) {
        await sql`
          UPDATE sms_verifications 
          SET code = ${code}, 
              expires_at = NOW() + INTERVAL '10 minutes',
              created_at = NOW()
          WHERE user_id = ${userId} 
          AND phone = ${phone} 
          AND verified = false
        `;
      } else {
        await sql`
          INSERT INTO sms_verifications (user_id, phone, code, expires_at)
          VALUES (${userId}, ${phone}, ${code}, NOW() + INTERVAL '10 minutes')
        `;
      }
    }

    const mockSmsResponse = await sendMockSMS(phone, smsMessage);

    if (!mockSmsResponse.success) {
      return {
        success: false,
        error: "Failed to send SMS: " + mockSmsResponse.error,
      };
    }

    return {
      success: true,
      message: "SMS sent successfully",
      messageId: mockSmsResponse.messageId,
      phone: phone.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2"),
    };
  } catch (error) {
    console.error("SMS sending error:", error);
    return {
      success: false,
      error: "Failed to send SMS. Please try again.",
    };
  }
}

async function sendMockSMS(phone, message) {
  await new Promise((resolve) => setTimeout(resolve, 1000));

  const shouldFail = Math.random() < 0.05;

  if (shouldFail) {
    return {
      success: false,
      error: "Network timeout",
    };
  }

  const messageId =
    "SMS_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);

  console.log(`[MOCK SMS] To: ${phone}`);
  console.log(`[MOCK SMS] Message: ${message}`);
  console.log(`[MOCK SMS] Message ID: ${messageId}`);

  return {
    success: true,
    messageId: messageId,
    status: "sent",
  };
}
export async function POST(request) {
  return handler(await request.json());
}