function handler({ action, email, phone, code, userId }) {
  const session = getSession();

  if (!session?.user?.id && !userId) {
    return { error: "Authentication required" };
  }

  const currentUserId = userId || session.user.id;

  switch (action) {
    case "send_email":
      return sendEmailVerification(email, currentUserId);
    case "send_sms":
      return sendSMSVerification(phone, currentUserId);
    case "verify_email":
      return verifyEmailCode(email, code, currentUserId);
    case "verify_sms":
      return verifySMSCode(phone, code, currentUserId);
    case "get_status":
      return getVerificationStatus(currentUserId);
    default:
      return { error: "Invalid action" };
  }
}

async function sendEmailVerification(email, userId) {
  try {
    if (!email) {
      return { error: "Email is required" };
    }

    const verificationCode = Math.floor(
      100000 + Math.random() * 900000
    ).toString();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000);

    await sql`
      INSERT INTO email_verifications (user_id, email, code, expires_at, created_at)
      VALUES (${userId}, ${email}, ${verificationCode}, ${expiresAt}, NOW())
      ON CONFLICT (user_id, email) 
      DO UPDATE SET 
        code = ${verificationCode},
        expires_at = ${expiresAt},
        created_at = NOW(),
        verified = false
    `;

    const emailResponse = await fetch(`${process.env.APP_URL}/api/send-email`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        to: email,
        subject: "EventTix - Email Verification Code",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #357AFF;">Email Verification</h2>
            <p>Your verification code is:</p>
            <div style="background: #f5f5f5; padding: 20px; text-align: center; font-size: 24px; font-weight: bold; letter-spacing: 3px; margin: 20px 0;">
              ${verificationCode}
            </div>
            <p>This code will expire in 15 minutes.</p>
            <p>If you didn't request this verification, please ignore this email.</p>
          </div>
        `,
      }),
    });

    if (!emailResponse.ok) {
      return { error: "Failed to send verification email" };
    }

    return {
      success: true,
      message: "Verification code sent to email",
      expiresAt: expiresAt.toISOString(),
    };
  } catch (error) {
    console.error("Email verification error:", error);
    return { error: "Failed to send email verification" };
  }
}

async function sendSMSVerification(phone, userId) {
  try {
    if (!phone) {
      return { error: "Phone number is required" };
    }

    const verificationCode = Math.floor(
      100000 + Math.random() * 900000
    ).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

    await sql`
      INSERT INTO sms_verifications (user_id, phone, code, expires_at, created_at)
      VALUES (${userId}, ${phone}, ${verificationCode}, ${expiresAt}, NOW())
      ON CONFLICT (user_id, phone) 
      DO UPDATE SET 
        code = ${verificationCode},
        expires_at = ${expiresAt},
        created_at = NOW(),
        verified = false
    `;

    const smsResponse = await fetch(`${process.env.APP_URL}/api/send-sms`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        to: phone,
        message: `EventTix verification code: ${verificationCode}. Valid for 10 minutes.`,
      }),
    });

    if (!smsResponse.ok) {
      return { error: "Failed to send SMS verification" };
    }

    return {
      success: true,
      message: "Verification code sent to phone",
      expiresAt: expiresAt.toISOString(),
    };
  } catch (error) {
    console.error("SMS verification error:", error);
    return { error: "Failed to send SMS verification" };
  }
}

async function verifyEmailCode(email, code, userId) {
  try {
    if (!email || !code) {
      return { error: "Email and code are required" };
    }

    const [verification] = await sql`
      SELECT * FROM email_verifications 
      WHERE user_id = ${userId} AND email = ${email} AND code = ${code}
      AND expires_at > NOW() AND verified = false
    `;

    if (!verification) {
      return { error: "Invalid or expired verification code" };
    }

    await sql`
      UPDATE email_verifications 
      SET verified = true, verified_at = NOW()
      WHERE user_id = ${userId} AND email = ${email} AND code = ${code}
    `;

    await sql`
      UPDATE auth_users 
      SET "emailVerified" = NOW()
      WHERE id = ${userId}
    `;

    return {
      success: true,
      message: "Email verified successfully",
      verified: true,
    };
  } catch (error) {
    console.error("Email verification error:", error);
    return { error: "Failed to verify email code" };
  }
}

async function verifySMSCode(phone, code, userId) {
  try {
    if (!phone || !code) {
      return { error: "Phone and code are required" };
    }

    const [verification] = await sql`
      SELECT * FROM sms_verifications 
      WHERE user_id = ${userId} AND phone = ${phone} AND code = ${code}
      AND expires_at > NOW() AND verified = false
    `;

    if (!verification) {
      return { error: "Invalid or expired verification code" };
    }

    await sql`
      UPDATE sms_verifications 
      SET verified = true, verified_at = NOW()
      WHERE user_id = ${userId} AND phone = ${phone} AND code = ${code}
    `;

    return {
      success: true,
      message: "Phone verified successfully",
      verified: true,
    };
  } catch (error) {
    console.error("SMS verification error:", error);
    return { error: "Failed to verify SMS code" };
  }
}

async function getVerificationStatus(userId) {
  try {
    const [user] = await sql`
      SELECT "emailVerified" FROM auth_users WHERE id = ${userId}
    `;

    const emailVerifications = await sql`
      SELECT email, verified, verified_at 
      FROM email_verifications 
      WHERE user_id = ${userId}
      ORDER BY created_at DESC
    `;

    const smsVerifications = await sql`
      SELECT phone, verified, verified_at 
      FROM sms_verifications 
      WHERE user_id = ${userId}
      ORDER BY created_at DESC
    `;

    return {
      success: true,
      emailVerified: !!user?.emailVerified,
      emailVerifications: emailVerifications || [],
      smsVerifications: smsVerifications || [],
    };
  } catch (error) {
    console.error("Get verification status error:", error);
    return { error: "Failed to get verification status" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}