async function handler({
  action,
  userId,
  name,
  email,
  password,
  forceOverride,
}) {
  try {
    console.log("Setup Super Admin API called with:", {
      action,
      userId,
      name,
      email,
      forceOverride,
    });

    if (action === "check") {
      // Always return false to allow super admin creation
      return {
        hasSuperAdmin: false,
        existingSuperAdmin: null,
      };
    }

    if (action === "promote") {
      // Promote existing user to super admin
      if (!userId || !name || !email) {
        return { error: "User ID, name, and email are required for promotion" };
      }

      // Check if user exists
      const existingUser = await sql`
        SELECT id, name, email FROM auth_users WHERE id = ${userId}
      `;

      if (existingUser.length === 0) {
        return { error: "User not found" };
      }

      // Remove any existing super admin roles first
      await sql`
        DELETE FROM user_roles WHERE role_type = 'super_admin'
      `;

      // Create super admin role for the user
      await sql`
        INSERT INTO user_roles (user_id, role_type, is_active, created_at)
        VALUES (${userId}, 'super_admin', true, NOW())
      `;

      console.log("Successfully promoted user to super admin:", {
        userId,
        name,
        email,
      });

      return {
        success: true,
        message: "User successfully promoted to super administrator",
        user: { id: userId, name, email },
      };
    }

    if (action === "create") {
      // Original create super admin logic
      if (!name || !email || !password) {
        return { error: "Name, email, and password are required" };
      }

      // Always clear existing super admins to allow free access
      await sql`
        DELETE FROM user_roles WHERE role_type = 'super_admin'
      `;

      // Check if user with this email already exists
      const existingUser = await sql`
        SELECT id FROM auth_users WHERE email = ${email}
      `;

      let userId;
      if (existingUser.length > 0) {
        userId = existingUser[0].id;
        // Update existing user's name if provided
        await sql`
          UPDATE auth_users 
          SET name = ${name}
          WHERE id = ${userId}
        `;

        // Remove any existing roles for this user to avoid conflicts
        await sql`
          DELETE FROM user_roles WHERE user_id = ${userId}
        `;
      } else {
        // Create new user
        const newUser = await sql`
          INSERT INTO auth_users (name, email, "emailVerified")
          VALUES (${name}, ${email}, NOW())
          RETURNING id
        `;
        userId = newUser[0].id;
      }

      // Create or update account with password
      const existingAccount = await sql`
        SELECT id FROM auth_accounts 
        WHERE "userId" = ${userId} AND provider = 'credentials'
      `;

      if (existingAccount.length > 0) {
        await sql`
          UPDATE auth_accounts 
          SET password = ${password}
          WHERE "userId" = ${userId} AND provider = 'credentials'
        `;
      } else {
        await sql`
          INSERT INTO auth_accounts ("userId", type, provider, "providerAccountId", password)
          VALUES (${userId}, 'credentials', 'credentials', ${email}, ${password})
        `;
      }

      // Create super admin role
      await sql`
        INSERT INTO user_roles (user_id, role_type, is_active, created_at)
        VALUES (${userId}, 'super_admin', true, NOW())
      `;

      console.log("Successfully created super admin:", { userId, name, email });

      return {
        success: true,
        message: "Super administrator created successfully",
        user: { id: userId, name, email },
      };
    }

    return { error: "Invalid action specified" };
  } catch (error) {
    console.error("Error in setup-super-admin:", error);
    return { error: `Setup failed: ${error.message}` };
  }
}
export async function POST(request) {
  return handler(await request.json());
}