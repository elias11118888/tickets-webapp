async function handler() {
  try {
    await sql.transaction([
      sql`DELETE FROM user_roles WHERE role_type = 'super_admin'`,
      sql`UPDATE user_roles SET is_active = false WHERE role_type IN ('admin', 'sub_admin')`,
    ]);

    return {
      success: true,
      message:
        "All super admin restrictions cleared. Any user can now become super admin.",
      cleared: {
        superAdminRoles: true,
        adminLocks: true,
      },
    };
  } catch (error) {
    console.error("Error clearing super admin lock:", error);
    return {
      success: false,
      error: "Failed to clear super admin restrictions",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}