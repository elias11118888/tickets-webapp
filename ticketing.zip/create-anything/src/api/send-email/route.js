async function handler({ to, subject, type, data }) {
  if (!to || !subject || !type) {
    return {
      success: false,
      error: "Missing required fields: to, subject, type",
    };
  }

  try {
    let emailContent = "";

    switch (type) {
      case "verification":
        if (!data?.code) {
          return {
            success: false,
            error: "Verification code is required",
          };
        }
        emailContent = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #357AFF;">Email Verification</h2>
            <p>Your verification code is:</p>
            <div style="background: #f5f5f5; padding: 20px; text-align: center; font-size: 24px; font-weight: bold; letter-spacing: 3px; margin: 20px 0;">
              ${data.code}
            </div>
            <p>This code will expire in 10 minutes.</p>
            <p>If you didn't request this verification, please ignore this email.</p>
          </div>
        `;
        break;

      case "welcome":
        emailContent = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #357AFF;">Welcome to EventTix!</h2>
            <p>Hello ${data?.name || "there"},</p>
            <p>Welcome to EventTix! Your account has been successfully created.</p>
            <p>You can now:</p>
            <ul>
              <li>Browse and book tickets for amazing events</li>
              <li>Manage your ticket purchases</li>
              <li>Stay updated on upcoming events</li>
            </ul>
            <p>Thank you for joining EventTix!</p>
          </div>
        `;
        break;

      case "ticket_confirmation":
        if (!data?.ticketNumber || !data?.eventTitle) {
          return {
            success: false,
            error: "Ticket number and event title are required",
          };
        }
        emailContent = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #357AFF;">Ticket Confirmation</h2>
            <p>Your ticket has been confirmed!</p>
            <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
              <h3>${data.eventTitle}</h3>
              <p><strong>Ticket Number:</strong> ${data.ticketNumber}</p>
              <p><strong>Quantity:</strong> ${data.quantity || 1}</p>
              <p><strong>Total Amount:</strong> $${
                data.totalAmount || "0.00"
              }</p>
              ${
                data.eventDate
                  ? `<p><strong>Event Date:</strong> ${data.eventDate}</p>`
                  : ""
              }
              ${
                data.venue ? `<p><strong>Venue:</strong> ${data.venue}</p>` : ""
              }
            </div>
            <p>Please keep this email as your ticket confirmation.</p>
          </div>
        `;
        break;

      case "event_approved":
        if (!data?.eventTitle) {
          return {
            success: false,
            error: "Event title is required",
          };
        }
        emailContent = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #357AFF;">Event Approved!</h2>
            <p>Great news! Your event has been approved and is now live.</p>
            <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
              <h3>${data.eventTitle}</h3>
              <p>Your event is now visible to users and tickets can be purchased.</p>
            </div>
            <p>Thank you for using EventTix!</p>
          </div>
        `;
        break;

      case "event_rejected":
        if (!data?.eventTitle) {
          return {
            success: false,
            error: "Event title is required",
          };
        }
        emailContent = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #357AFF;">Event Update Required</h2>
            <p>Your event submission needs some updates before it can be approved.</p>
            <div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">
              <h3>${data.eventTitle}</h3>
              ${
                data.reason
                  ? `<p><strong>Reason:</strong> ${data.reason}</p>`
                  : ""
              }
            </div>
            <p>Please review and resubmit your event for approval.</p>
          </div>
        `;
        break;

      case "admin_notification":
        emailContent = `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #357AFF;">Admin Notification</h2>
            <p>${data?.message || "You have a new admin notification."}</p>
            ${
              data?.details
                ? `<div style="background: #f5f5f5; padding: 20px; margin: 20px 0;">${data.details}</div>`
                : ""
            }
          </div>
        `;
        break;

      default:
        return {
          success: false,
          error: "Invalid email type",
        };
    }

    console.log(`[MOCK EMAIL SERVICE] Sending email to: ${to}`);
    console.log(`[MOCK EMAIL SERVICE] Subject: ${subject}`);
    console.log(`[MOCK EMAIL SERVICE] Type: ${type}`);
    console.log(`[MOCK EMAIL SERVICE] Content: ${emailContent}`);

    await new Promise((resolve) => setTimeout(resolve, 500));

    const emailLog = await sql`
      INSERT INTO admin_activity_log (
        admin_id, 
        action_type, 
        target_type, 
        description, 
        metadata
      ) VALUES (
        NULL,
        'email_sent',
        'email',
        ${`Email sent to ${to}: ${subject}`},
        ${JSON.stringify({
          to,
          subject,
          type,
          timestamp: new Date().toISOString(),
        })}
      )
    `;

    return {
      success: true,
      message: "Email sent successfully",
      emailId: `mock_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      to,
      subject,
      type,
    };
  } catch (error) {
    console.error("Error sending email:", error);
    return {
      success: false,
      error: "Failed to send email",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}