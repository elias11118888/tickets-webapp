"use client";
import React from "react";

function MainComponent() {
  const { signUpWithCredentials, signInWithGoogle } = useAuth();
  const [step, setStep] = useState(1); // 1: signup, 2: email verification, 3: mobile verification, 4: complete
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    mobile: "",
    countryCode: "+233",
  });
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [verificationId, setVerificationId] = useState("");
  const [resendTimer, setResendTimer] = useState(0);

  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendTimer]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setError("");
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match");
      setLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters long");
      setLoading(false);
      return;
    }

    try {
      const result = await signUpWithCredentials({
        email: formData.email,
        password: formData.password,
        name: formData.name,
        redirect: false,
      });

      if (result?.error) {
        throw new Error(result.error);
      }

      await sendEmailVerification();
      setStep(2);
      setSuccess("Account created! Please check your email for verification.");
    } catch (error) {
      console.error("Signup error:", error);
      setError(error.message || "Failed to create account");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignup = async () => {
    setLoading(true);
    setError("");

    try {
      await signInWithGoogle({
        callbackUrl: "/dashboard",
        redirect: true,
      });
    } catch (error) {
      console.error("Google signup error:", error);
      setError("Failed to sign up with Google");
      setLoading(false);
    }
  };

  const sendEmailVerification = async () => {
    try {
      const verificationCode = Math.floor(
        100000 + Math.random() * 900000
      ).toString();

      const response = await fetch("/api/send-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: formData.email,
          subject: "EventTix - Email Verification Code",
          type: "verification",
          data: { code: verificationCode },
        }),
      });

      if (!response.ok) throw new Error("Failed to send verification email");

      // Store verification code temporarily (in real app, this would be stored server-side)
      sessionStorage.setItem("emailVerificationCode", verificationCode);
      setResendTimer(60);
    } catch (error) {
      console.error("Email verification error:", error);
      setError("Failed to send verification email");
    }
  };

  const verifyEmail = async () => {
    setLoading(true);
    setError("");

    try {
      const storedCode = sessionStorage.getItem("emailVerificationCode");

      if (otp !== storedCode) {
        throw new Error("Invalid verification code");
      }

      sessionStorage.removeItem("emailVerificationCode");
      setStep(3);
      setOtp("");
      setSuccess("Email verified! Now verify your mobile number.");
    } catch (error) {
      console.error("Email verification error:", error);
      setError("Invalid verification code");
    } finally {
      setLoading(false);
    }
  };

  const sendMobileOTP = async () => {
    setLoading(true);
    setError("");

    try {
      const verificationCode = Math.floor(
        100000 + Math.random() * 900000
      ).toString();

      const response = await fetch("/api/send-sms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone: formData.countryCode + formData.mobile,
          code: verificationCode,
          type: "verification",
        }),
      });

      if (!response.ok) throw new Error("Failed to send OTP");

      // Store verification code temporarily (in real app, this would be stored server-side)
      sessionStorage.setItem("mobileVerificationCode", verificationCode);
      setVerificationId("mock_verification_id");
      setResendTimer(60);
      setSuccess("OTP sent to your mobile number");
    } catch (error) {
      console.error("Mobile OTP error:", error);
      setError("Failed to send OTP");
    } finally {
      setLoading(false);
    }
  };

  const verifyMobile = async () => {
    setLoading(true);
    setError("");

    try {
      const storedCode = sessionStorage.getItem("mobileVerificationCode");

      if (otp !== storedCode) {
        throw new Error("Invalid OTP");
      }

      sessionStorage.removeItem("mobileVerificationCode");
      setStep(4);
      setSuccess("Mobile number verified! Redirecting to dashboard...");

      setTimeout(() => {
        window.location.href = "/dashboard";
      }, 2000);
    } catch (error) {
      console.error("Mobile verification error:", error);
      setError("Invalid OTP");
    } finally {
      setLoading(false);
    }
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-2">Create Account</h2>
        <p className="text-white/70">
          Join EventTix and start creating amazing events
        </p>
      </div>

      <button
        onClick={handleGoogleSignup}
        disabled={loading}
        className="w-full bg-white text-gray-900 py-3 px-4 rounded-lg font-medium hover:bg-gray-100 transition-colors disabled:opacity-50 flex items-center justify-center"
      >
        <i className="fab fa-google mr-3 text-red-500"></i>
        Continue with Google
      </button>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-white/20"></div>
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-2 bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460] text-white/70">
            Or continue with email
          </span>
        </div>
      </div>

      <form onSubmit={handleSignup} className="space-y-4">
        <div>
          <label className="block text-white/70 text-sm mb-2">Full Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#357AFF] focus:border-transparent"
            placeholder="Enter your full name"
            required
          />
        </div>

        <div>
          <label className="block text-white/70 text-sm mb-2">
            Email Address
          </label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#357AFF] focus:border-transparent"
            placeholder="Enter your email"
            required
          />
        </div>

        <div>
          <label className="block text-white/70 text-sm mb-2">Password</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#357AFF] focus:border-transparent"
            placeholder="Create a password"
            required
            minLength="6"
          />
        </div>

        <div>
          <label className="block text-white/70 text-sm mb-2">
            Confirm Password
          </label>
          <input
            type="password"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleInputChange}
            className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#357AFF] focus:border-transparent"
            placeholder="Confirm your password"
            required
            minLength="6"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-[#357AFF] text-white py-3 px-4 rounded-lg font-medium hover:bg-[#2E69DE] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {loading ? (
            <>
              <i className="fas fa-spinner fa-spin mr-2"></i>
              Creating Account...
            </>
          ) : (
            <>
              <i className="fas fa-user-plus mr-2"></i>
              Create Account
            </>
          )}
        </button>
      </form>

      <div className="text-center">
        <p className="text-white/70 text-sm">
          Already have an account?{" "}
          <a href="/account/signin" className="text-[#357AFF] hover:underline">
            Sign in
          </a>
        </p>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <i className="fas fa-envelope text-[#357AFF] text-5xl mb-4"></i>
        <h2 className="text-2xl font-bold text-white mb-2">
          Verify Your Email
        </h2>
        <p className="text-white/70">
          We've sent a verification code to{" "}
          <span className="text-white font-medium">{formData.email}</span>
        </p>
      </div>

      <div>
        <label className="block text-white/70 text-sm mb-2">
          Verification Code
        </label>
        <input
          type="text"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#357AFF] focus:border-transparent text-center text-2xl tracking-widest md:bg-white/10 md:text-white md:placeholder-white/50 bg-white text-black placeholder-gray-500"
          placeholder="000000"
          maxLength="6"
          required
        />
      </div>

      <button
        onClick={verifyEmail}
        disabled={loading || otp.length !== 6}
        className="w-full bg-[#357AFF] text-white py-3 px-4 rounded-lg font-medium hover:bg-[#2E69DE] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
      >
        {loading ? (
          <>
            <i className="fas fa-spinner fa-spin mr-2"></i>
            Verifying...
          </>
        ) : (
          <>
            <i className="fas fa-check mr-2"></i>
            Verify Email
          </>
        )}
      </button>

      <div className="text-center">
        <p className="text-white/70 text-sm">
          Didn't receive the code?{" "}
          {resendTimer > 0 ? (
            <span className="text-white/50">Resend in {resendTimer}s</span>
          ) : (
            <button
              onClick={sendEmailVerification}
              className="text-[#357AFF] hover:underline"
            >
              Resend code
            </button>
          )}
        </p>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <i className="fas fa-mobile-alt text-[#357AFF] text-5xl mb-4"></i>
        <h2 className="text-2xl font-bold text-white mb-2">
          Verify Mobile Number
        </h2>
        <p className="text-white/70">
          Add and verify your mobile number for account security
        </p>
      </div>

      <div className="flex space-x-3">
        <select
          name="countryCode"
          value={formData.countryCode}
          onChange={handleInputChange}
          className="bg-white/10 border border-white/20 rounded-lg px-3 py-3 text-white focus:outline-none focus:ring-2 focus:ring-[#357AFF] focus:border-transparent"
        >
          <option value="+233">🇬🇭 +233</option>
          <option value="+1">🇺🇸 +1</option>
          <option value="+44">🇬🇧 +44</option>
          <option value="+234">🇳🇬 +234</option>
        </select>
        <input
          type="tel"
          name="mobile"
          value={formData.mobile}
          onChange={handleInputChange}
          className="flex-1 bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#357AFF] focus:border-transparent"
          placeholder="Enter mobile number"
          required
        />
      </div>

      {!verificationId ? (
        <button
          onClick={sendMobileOTP}
          disabled={loading || !formData.mobile}
          className="w-full bg-[#357AFF] text-white py-3 px-4 rounded-lg font-medium hover:bg-[#2E69DE] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        >
          {loading ? (
            <>
              <i className="fas fa-spinner fa-spin mr-2"></i>
              Sending OTP...
            </>
          ) : (
            <>
              <i className="fas fa-paper-plane mr-2"></i>
              Send OTP
            </>
          )}
        </button>
      ) : (
        <div className="space-y-4">
          <div>
            <label className="block text-white/70 text-sm mb-2">
              Enter OTP
            </label>
            <input
              type="text"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              className="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#357AFF] focus:border-transparent text-center text-2xl tracking-widest"
              placeholder="000000"
              maxLength="6"
              required
            />
          </div>

          <button
            onClick={verifyMobile}
            disabled={loading || otp.length !== 6}
            className="w-full bg-[#357AFF] text-white py-3 px-4 rounded-lg font-medium hover:bg-[#2E69DE] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
          >
            {loading ? (
              <>
                <i className="fas fa-spinner fa-spin mr-2"></i>
                Verifying...
              </>
            ) : (
              <>
                <i className="fas fa-check mr-2"></i>
                Verify Mobile
              </>
            )}
          </button>

          <div className="text-center">
            <p className="text-white/70 text-sm">
              Didn't receive the OTP?{" "}
              {resendTimer > 0 ? (
                <span className="text-white/50">Resend in {resendTimer}s</span>
              ) : (
                <button
                  onClick={sendMobileOTP}
                  className="text-[#357AFF] hover:underline"
                >
                  Resend OTP
                </button>
              )}
            </p>
          </div>
        </div>
      )}

      <div className="text-center">
        <button
          onClick={() => setStep(4)}
          className="text-white/70 hover:text-white text-sm"
        >
          Skip mobile verification
        </button>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-6 text-center">
      <div className="mb-8">
        <i className="fas fa-check-circle text-green-400 text-6xl mb-4"></i>
        <h2 className="text-2xl font-bold text-white mb-2">
          Account Created Successfully!
        </h2>
        <p className="text-white/70">
          Welcome to EventTix! Redirecting to your dashboard...
        </p>
      </div>

      <div className="bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/20">
        <h3 className="text-lg font-semibold text-white mb-4">What's Next?</h3>
        <div className="space-y-3 text-left">
          <div className="flex items-center space-x-3">
            <i className="fas fa-calendar-plus text-[#357AFF]"></i>
            <span className="text-white/80">Create your first event</span>
          </div>
          <div className="flex items-center space-x-3">
            <i className="fas fa-users text-[#357AFF]"></i>
            <span className="text-white/80">Invite attendees</span>
          </div>
          <div className="flex items-center space-x-3">
            <i className="fas fa-chart-line text-[#357AFF]"></i>
            <span className="text-white/80">Track your event analytics</span>
          </div>
        </div>
      </div>

      <button
        onClick={() => (window.location.href = "/dashboard")}
        className="w-full bg-[#357AFF] text-white py-3 px-4 rounded-lg font-medium hover:bg-[#2E69DE] transition-colors flex items-center justify-center"
      >
        <i className="fas fa-arrow-right mr-2"></i>
        Go to Dashboard
      </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460] relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="particle particle-1"></div>
        <div className="particle particle-2"></div>
        <div className="particle particle-3"></div>
        <div className="geometric-shape shape-1"></div>
        <div className="geometric-shape shape-2"></div>
      </div>

      <div className="relative z-10 flex items-center justify-center min-h-screen px-4 py-8">
        <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 w-full max-w-md border border-white/20">
          {/* Progress Indicator */}
          <div className="flex justify-center mb-8">
            <div className="flex space-x-2">
              {[1, 2, 3, 4].map((stepNum) => (
                <div
                  key={stepNum}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    stepNum <= step ? "bg-[#357AFF]" : "bg-white/20"
                  }`}
                ></div>
              ))}
            </div>
          </div>

          {/* Error/Success Messages */}
          {error && (
            <div className="bg-red-500/20 border border-red-500/50 text-red-200 px-4 py-3 rounded-lg mb-6 flex items-center">
              <i className="fas fa-exclamation-circle mr-2"></i>
              {error}
            </div>
          )}

          {success && (
            <div className="bg-green-500/20 border border-green-500/50 text-green-200 px-4 py-3 rounded-lg mb-6 flex items-center">
              <i className="fas fa-check-circle mr-2"></i>
              {success}
            </div>
          )}

          {/* Step Content */}
          {step === 1 && renderStep1()}
          {step === 2 && renderStep2()}
          {step === 3 && renderStep3()}
          {step === 4 && renderStep4()}

          {/* Footer */}
          <div className="mt-8 text-center">
            <a
              href="/"
              className="text-white/70 hover:text-white transition-colors text-sm flex items-center justify-center"
            >
              <i className="fas fa-arrow-left mr-2"></i>
              Back to Homepage
            </a>
          </div>
        </div>
      </div>

      <style jsx global>{`
        .particle {
          position: absolute;
          background: rgba(53, 122, 255, 0.3);
          border-radius: 50%;
          animation: float 20s infinite linear;
        }

        .particle-1 {
          width: 4px;
          height: 4px;
          top: 20%;
          left: 10%;
          animation-delay: 0s;
        }

        .particle-2 {
          width: 3px;
          height: 3px;
          top: 60%;
          left: 80%;
          animation-delay: -10s;
        }

        .particle-3 {
          width: 5px;
          height: 5px;
          top: 80%;
          left: 20%;
          animation-delay: -20s;
        }

        .geometric-shape {
          position: absolute;
          border: 1px solid rgba(53, 122, 255, 0.2);
          animation: rotate 40s infinite linear;
        }

        .shape-1 {
          width: 60px;
          height: 60px;
          top: 15%;
          right: 15%;
          transform: rotate(45deg);
        }

        .shape-2 {
          width: 40px;
          height: 40px;
          top: 70%;
          left: 15%;
          border-radius: 50%;
          animation-delay: -20s;
        }

        @keyframes float {
          0% {
            transform: translateY(0px) translateX(0px);
            opacity: 0;
          }
          10% {
            opacity: 1;
          }
          90% {
            opacity: 1;
          }
          100% {
            transform: translateY(-100vh) translateX(50px);
            opacity: 0;
          }
        }

        @keyframes rotate {
          0% {
            transform: rotate(0deg);
          }
          100% {
            transform: rotate(360deg);
          }
        }
      `}</style>
    </div>
  );
}

export default MainComponent;