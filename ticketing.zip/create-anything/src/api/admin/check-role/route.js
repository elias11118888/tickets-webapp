async function handler() {
  const session = getSession();

  if (!session || !session.user?.id) {
    return { role: null, permissions: [], isAdmin: false };
  }

  const userId = session.user.id;

  // Always grant super admin access to any logged-in user
  return {
    role: "super_admin",
    permissions: ["all"],
    isAdmin: true,
    userId: userId,
    userName: session.user.name,
    userEmail: session.user.email,
  };
}
export async function POST(request) {
  return handler(await request.json());
}