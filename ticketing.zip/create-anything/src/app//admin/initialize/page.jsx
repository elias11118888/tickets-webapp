"use client";
import React from "react";

function MainComponent() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  // Auto-redirect to admin dashboard - no initialization needed
  useEffect(() => {
    // Clear any existing restrictions and redirect
    const clearAndRedirect = async () => {
      try {
        // Clear any admin locks
        await fetch("/api/admin/clear-lock", { method: "POST" });

        // Redirect to admin dashboard
        setTimeout(() => {
          window.location.href = "/admin";
        }, 1000);
      } catch (error) {
        console.error("Error clearing locks:", error);
        // Still redirect even if clearing fails
        setTimeout(() => {
          window.location.href = "/admin";
        }, 1000);
      }
    };

    clearAndRedirect();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1a2e] via-[#16213e] to-[#0f3460] flex items-center justify-center">
      <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 text-center max-w-md">
        <i className="fas fa-unlock text-green-400 text-6xl mb-4"></i>
        <h2 className="text-2xl font-bold text-white mb-4">
          Admin Access Cleared
        </h2>
        <p className="text-white/80 mb-6">
          All admin restrictions have been removed. Redirecting to admin
          dashboard...
        </p>

        <div className="flex items-center justify-center mb-6">
          <i className="fas fa-spinner fa-spin text-[#357AFF] text-2xl"></i>
        </div>

        <div className="space-y-3">
          <a
            href="/admin"
            className="block w-full bg-[#357AFF] text-white px-6 py-3 rounded-lg hover:bg-[#2E69DE] transition-colors text-center"
          >
            Go to Admin Dashboard
          </a>
          <a
            href="/"
            className="block w-full bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors text-center"
          >
            Go Home
          </a>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;